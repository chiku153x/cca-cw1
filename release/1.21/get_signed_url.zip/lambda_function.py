import logging
import boto3
from botocore.exceptions import ClientError
import json
import os

BUCKET = os.environ['BUCKET']
INPREFIX = os.environ['INPREFIX']


def lambda_handler(event, context):
    body = json.loads(event['body'])
    url = boto3.client('s3').generate_presigned_url( ClientMethod='put_object',  Params={'Bucket': BUCKET, 'Key':  body['file_name']}, ExpiresIn=3600, signature_version=s3_signature['v4'])
    return {
        'body':json.dumps(url),
        'headers': {
            'Content-Type': 'application/json'
        },
        'statusCode': 200
    }


