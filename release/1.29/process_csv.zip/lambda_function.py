import boto3
import json
import os


s3_client = boto3.client("s3")

BUCKET = os.environ['BUCKET']
OUTPREFIX = os.environ['OUTPREFIX']

def lambda_handler(event, context):
    print(json.dumps(event))
    key = event['Records'][0]['s3']['object']['key']
    response = s3_client.head_object(Bucket=BUCKET, Key=key)
    print(response)






