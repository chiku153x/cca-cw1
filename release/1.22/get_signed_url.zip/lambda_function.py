import logging
import boto3
from botocore.exceptions import ClientError
from botocore.client import Config
import json
import os

BUCKET = os.environ['BUCKET']
INPREFIX = os.environ['INPREFIX']


def lambda_handler(event, context):
    body = json.loads(event['body'])
    url = boto3.client('s3',config=Config(signature_version='s3v4')).generate_presigned_url( ClientMethod='put_object',  Params={'Bucket': BUCKET, 'Key':  body['file_name']}, ExpiresIn=3600)
    return {
        'body':json.dumps(url),
        'headers': {
            'Content-Type': 'application/json'
        },
        'statusCode': 200
    }


