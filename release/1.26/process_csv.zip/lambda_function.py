import boto3
import json
import os

BUCKET = os.environ['BUCKET']
OUTPREFIX = os.environ['OUTPREFIX']

def lambda_handler(event, context):
    print(json.dumps(event))

    # return {
    #     'body':json.dumps(event),
    #     'headers': {
    #         'Content-Type': 'application/json'
    #     },
    #     'statusCode': 200
    # }


