import boto3
from botocore.exceptions import ClientError
from botocore.client import Config
import json
import os

import requests

BUCKET = os.environ['BUCKET']
INPREFIX = os.environ['INPREFIX']

s3_client = boto3.client(
    's3'
)


OBJ_NAME = '/tmp/try.txt'


def create_file():
    with open(OBJ_NAME, 'w') as out_file:
        out_file.write("ABC123")


def lambda_handler(event, context):
    create_file()

    body = json.loads(event['body'])
    r = s3_client.generate_presigned_post( Bucket = BUCKET, Key = body['file_name'], ExpiresIn=20)
    print(r)
    files  = {'file':open(OBJ_NAME , 'rb')}
    x = requests.post(r['url'],data = r['fields'], files=files)

    return {
        'body':json.dumps(r),
        'headers': {
            'Content-Type': 'application/json'
        },
        'statusCode': 200
    }


