import boto3
import json

import logging
import boto3
from botocore.exceptions import ClientError
import os

BUCKET = os.environ['BUCKET'] 

import logging
import boto3
from botocore.exceptions import ClientError


def create_presigned_post(bucket_name, object_name,
                          fields=None, conditions=None, expiration=3600):

    s3_client = boto3.client('s3')
    try:
        response = s3_client.generate_presigned_post(bucket_name,
                                                     object_name,
                                                     Fields=fields,
                                                     Conditions=conditions,
                                                     ExpiresIn=expiration)
    except ClientError as e:
        logging.error(e)
        return None

    return response



def lambda_handler(event, context):
    #create_presigned_post(BUCKET,)
    return {
        'body':json.dumps(event),
        'headers': {
            'Content-Type': 'application/json'
        },
        'statusCode': 200
    }


