import logging
import boto3
from botocore.exceptions import ClientError
import json
import os

BUCKET = os.environ['BUCKET']
def create_presigned_post(bucket_name, object_name,
                          fields=None, conditions=None, expiration=3600):

    s3_client = boto3.client('s3')
    try:
        response = s3_client.generate_presigned_post(bucket_name,
                                                     object_name,
                                                     Fields=fields,
                                                     Conditions=conditions,
                                                     ExpiresIn=expiration)
    except ClientError as e:
        logging.error(e)
        return None

    return response


def lambda_handler(event, context):
    body = json.loads(event['body'])
    psu = create_presigned_post(BUCKET,body['file_name'])
    return {
        'body':json.dumps(psu),
        'headers': {
            'Content-Type': 'application/json'
        },
        'statusCode': 200
    }


